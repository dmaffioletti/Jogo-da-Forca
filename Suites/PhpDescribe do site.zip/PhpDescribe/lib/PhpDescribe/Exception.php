<?php
namespace PhpDescribe;

class Exception extends \Exception {}
