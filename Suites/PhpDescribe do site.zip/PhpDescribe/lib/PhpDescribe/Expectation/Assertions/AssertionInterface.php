<?php
namespace PhpDescribe\Expectation\Assertions;

interface AssertionInterface{}