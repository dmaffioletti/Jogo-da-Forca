<?php
namespace PhpDescribe\Expectation;

class InvalidExpectationParameterException extends \PhpDescribe\Exception {}