<?php
namespace PhpDescribe\Result;
use \SplDoublyLinkedList;
class ResultList extends SplDoublyLinkedList {}