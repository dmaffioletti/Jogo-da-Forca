<?php
require_once('PSpec/Spec/spec_functions.php');