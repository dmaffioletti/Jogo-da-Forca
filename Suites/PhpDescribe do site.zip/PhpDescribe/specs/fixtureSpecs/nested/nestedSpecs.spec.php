<?php
namespace PhpDescribe\Spec;
describe('Parent Spec', function() {
    describe('nested spec', function() {
      it('should pass', function() {
          force_working();
      });
    });
});