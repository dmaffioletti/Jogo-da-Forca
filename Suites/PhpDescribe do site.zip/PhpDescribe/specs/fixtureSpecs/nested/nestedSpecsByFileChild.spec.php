<?php
namespace PhpDescribe\Spec;

describe('nested spec', function() {
  it('should pass', function() {
      force_working();
  });
});
