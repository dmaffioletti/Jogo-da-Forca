<?php
namespace PhpDescribe\Spec;
describe('Parent Spec', function() {
    addSpec(__DIR__ . '/nestedSpecsByFileChild');
});
