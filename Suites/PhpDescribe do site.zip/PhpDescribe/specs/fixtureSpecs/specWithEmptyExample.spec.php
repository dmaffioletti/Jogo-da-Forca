<?php
namespace PhpDescribe\Spec;
describe('Test2', function() {
    it('has an empty specification', function() {

    });
});
