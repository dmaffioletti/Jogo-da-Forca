<?php
namespace PhpDescribe\Spec;
describe('Failing spec', function() {
    it('Not working example', function() {
        force_not_working();
    });
});
