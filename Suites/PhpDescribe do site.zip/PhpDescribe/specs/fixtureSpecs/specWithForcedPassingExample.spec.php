<?php
namespace PhpDescribe\Spec;
describe('Passing spec', function() {
    it('passing example', function() {
        force_working();
    });
});
