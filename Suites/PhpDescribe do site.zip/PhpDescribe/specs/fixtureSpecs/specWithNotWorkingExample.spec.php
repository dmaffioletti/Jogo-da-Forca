<?php
namespace PhpDescribe\Spec;
describe('Not Working example', function() {
    it('n w example', function() {
        expect(1)->should('be',2);
    });
});
