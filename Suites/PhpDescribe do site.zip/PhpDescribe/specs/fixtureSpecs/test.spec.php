<?php
namespace PhpDescribe\Spec;
describe('Test', function() {

});